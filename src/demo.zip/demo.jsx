import React, { useState } from 'react';

const FormGenerator = () => {
  const [formFields, setFormFields] = useState([]);
  const [formData, setFormData] = useState({});
  const [errors, setErrors] = useState({});

  const addFormField = (type) => {
    const newField = { type, label: '', options: [] };
    setFormFields([...formFields, newField]);
  };

  const removeFormField = (index) => {
    const updatedFields = [...formFields];
    updatedFields.splice(index, 1);
    setFormFields(updatedFields);
  };

  const handleInputChange = (index, key, value) => {
    const updatedFields = [...formFields];
    updatedFields[index][key] = value;
    setFormFields(updatedFields);
  };

  const handleOptionChange = (index, optionIndex, value) => {
    const updatedFields = [...formFields];
    updatedFields[index].options[optionIndex] = value;
    setFormFields(updatedFields);
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    // Form validation logic goes here
    console.log(formData);
  };

  const renderFormField = (field, index) => {
    switch (field.type) {
      case 'text':
      case 'textarea':
        return (
          <div key={index}>
            <label>
              {field.label}:
              <input
                type={field.type}
                value={formData[field.label]}
                onChange={(e) => setFormData({ ...formData, [field.label]: e.target.value })}
              />
            </label>
          </div>
        );
      case 'dropdown':
        return (
          <div key={index}>
            <label>
              {field.label}:
              <select
                value={formData[field.label]}
                onChange={(e) => setFormData({ ...formData, [field.label]: e.target.value })}
              >
                {field.options.map((option, optionIndex) => (
                  <option key={optionIndex} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </label>
          </div>
        );
      // Implement other cases for checkbox, radio button, file upload
      default:
        return null;
    }
  };

  return (
    <div>
      <h1>Dynamic Form Generator</h1>
      <form onSubmit={handleFormSubmit}>
        {formFields.map((field, index) => (
          <div key={index}>
            <div>
              <input type="text" value={field.label} onChange={(e) => handleInputChange(index, 'label', e.target.value)} />
              <select value={field.type} onChange={(e) => handleInputChange(index, 'type', e.target.value)}>
                <option value="text">Text Input</option>
                <option value="textarea">Text Area</option>
                <option value="dropdown">Dropdown</option>
                {/* Add options for other field types */}
              </select>
              <button type="button" onClick={() => removeFormField(index)}>Remove</button>
            </div>
            {field.type === 'dropdown' && (
              <div>
                {field.options.map((option, optionIndex) => (
                  <input
                    key={optionIndex}
                    type="text"
                    value={option}
                    onChange={(e) => handleOptionChange(index, optionIndex, e.target.value)}
                  />
                ))}
                <button type="button" onClick={() => handleOptionChange(index, field.options.length, '')}>Add Option</button>
              </div>
            )}
          </div>
        ))}
        <button type="button" onClick={() => addFormField('text')}>Add Text Input</button>
        <button type="button" onClick={() => addFormField('textarea')}>Add Text Area</button>
        <button type="button" onClick={() => addFormField('dropdown')}>Add Dropdown</button>
        {/* Add buttons for other field types */}
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default FormGenerator;
